def say(message, times = 2):
    print(message*times)

say('Hello ')
say('World '*5)
say('earth ', 5)