while True:
    s = input("Enter text : ")
    if s == 'quit':
        break
    print('length of the string is ', len(s))
print('Done')