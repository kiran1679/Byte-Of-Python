class Person:
    pass #An empty block

p = Person()
print(p)

