while True:
    s = input("Enter text: ")
    if s == 'quit':
        break
    if len(s) < 3:
        print("Too Small")
        continue
    print("Input is insufficient length")
    #Do other kind of processig here