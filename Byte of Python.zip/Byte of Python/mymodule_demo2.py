from mymodule import say_hi,__version__

say_hi()
print('version',__version__)