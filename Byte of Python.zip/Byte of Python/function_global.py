x = 50
print(x)

def func():
    global x

    print('x is ',x)
    x = 2
    print('Changed global x to ',x)


x = 3


func()
print('value of x is ',x)
