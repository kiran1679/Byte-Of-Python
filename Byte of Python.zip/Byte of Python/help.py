#help ('len')

help('return')