name = input("What is your name ? ")
print("This is", len(name),"characters long.")