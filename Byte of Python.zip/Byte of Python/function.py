def say_hello() :
    print("Hello")

say_hello()
say_hello()
