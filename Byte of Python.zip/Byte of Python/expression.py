length = 5
breadth = 2

area= length * breadth
print("Area is : ", area)
print("Perimeter is : ", 2*(length + breadth))