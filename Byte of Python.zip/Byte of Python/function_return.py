def maximum(x, y):
    if x > y:
        return x
    elif x == y:
        return 'The numbers aree equal'
    else:
        return y


print(maximum(2,3))