age = 20
name= 'swaroop'

print('{0} was {1} year old when he wrote this book'.format(name, age))
print('why is {0} playing with that Python ?'.format(name))
#numbers are optional
print('{} was {} year old when he wrote this book'.format(name, age))
print('why is {} playing with that Python ?'.format(name))
#decimal (.) precision of 3 for float '0.333'
print('{0:.3f}'.format(1.0/3))
#fill with underscores (_) with the text centered
#(^) to 11 width "__hello__"
print('{0:_^11}'.format('hello'))
#keyword-based 'Swaroop wrote A Byte of Python'
print('{name} wrote {book}'.format(name='Swaroop', book='A Byte of Python'))
print('a', end='')
print('b', end='')
print('a', end=' ')
print('b', end=' ')
print('c', end=' ')
print("what's your name")
print('what\'s your name')
print('address is 27\\4, hyderabad')
print('This is the first line.\nThis is the second line')
print('This is the a.\tThis is b')
print('This is a.  \
This is b')
print(r"New lines are indicated by \n")
print(R"Raw string is printed by using r or R in prefix like \n or \t")