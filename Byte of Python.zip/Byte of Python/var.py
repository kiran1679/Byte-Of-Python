i = 5
print(i)
i = i+1
print(i)

s = '''This is multi line string.
This is second line.'''
print(s)