print(''' This is multiple lines.
print multiple lines.
''')